@echo off
rem Drag your ORIGINAL .slbk backup onto this file. plan.json must be in this folder.
if "%~1"=="" (
  echo Drag your original .slbk backup onto this file.
  pause
  exit /b
)
if not exist "%~dp0plan.json" (
  echo plan.json not found in this folder. Save the plan from the chat as plan.json here.
  pause
  exit /b
)
set PY=python
where py >nul 2>&1 && set PY=py
%PY% "%~dp0slb_apply.py" "%~1" "%~dp0plan.json"
echo.
echo Paste the text above into the chat if anything looks wrong.
pause
