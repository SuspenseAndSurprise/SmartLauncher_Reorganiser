"""Smart Launcher backup inspector. Read-only: never changes your backup.

Usage:  python slb_inspect.py your_backup.slbk > inspect_output.txt
Then paste inspect_output.txt into the chat.
"""
import os
import re
import sqlite3
import sys
import tempfile
import zipfile

DB = "databases/ginlemon.flower.db"
sys.stdout.reconfigure(encoding="utf-8")


def table_cols(con, table):
    return [r[1] for r in con.execute(f'PRAGMA table_info("{table}")')]


def dump(con, sql, limit=300):
    cur = con.execute(sql)
    cols = [d[0] for d in cur.description]
    print(" | ".join(cols))
    rows = cur.fetchall()
    for r in rows[:limit]:
        print(" | ".join("" if v is None else str(v) for v in r))
    if len(rows) > limit:
        print(f"... {len(rows) - limit} more rows")


def main(path):
    z = zipfile.ZipFile(path)
    names = z.namelist()
    if DB not in names:
        sys.exit(f"Not a Smart Launcher backup: {DB} not found. Entries: {names[:20]}")

    print("== ARCHIVE ==")
    print(f"{len(names)} entries")
    for n in names[:60]:
        print(" ", n)
    if len(names) > 60:
        print(f"  ... {len(names) - 60} more")

    for n in names:
        if n.startswith("shared_prefs/") and n.endswith(".xml"):
            text = z.read(n).decode("utf-8", "replace")
            for m in re.finditer(r'name="(launcher_profile_[^"]*)"[^>]*?(?:value="([^"]*)"|>([^<]*)<)', text):
                print(f"\n== {m.group(1)} (in {n}) ==")
                print((m.group(2) or m.group(3) or "").replace("&quot;", '"')[:1500])
            print("\n== SETTINGS (drawer) ==")
            for key in ("drawerOrder", "stackFromBottom"):
                m = re.search(r'<[^>]*name="%s"[^>]*>' % key, text)
                print(m.group(0) if m else f"{key}: not present")
            print("(drawerOrder 1 = most used, 3 = manual. stackFromBottom true = fills from the bottom, missing = off)")
        if n == "files/metadata/info":
            print("\n== files/metadata/info ==")
            print(z.read(n).decode("utf-8", "replace")[:400])

    tmp = tempfile.mkdtemp()
    for n in names:
        if n.startswith(DB):
            with open(os.path.join(tmp, os.path.basename(n)), "wb") as f:
                f.write(z.read(n))
    con = sqlite3.connect(os.path.join(tmp, os.path.basename(DB)))

    print("\n== TABLES (row counts) ==")
    tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
    for t in tables:
        print(f"  {t}: {con.execute(f'SELECT COUNT(*) FROM \"{t}\"').fetchone()[0]}")

    print("\n== SCHEMA ==")
    for t in ("Category", "DrawerItem", "HomeItem", "Launchable", "Action"):
        row = con.execute("SELECT sql FROM sqlite_master WHERE name=?", (t,)).fetchone()
        print(row[0] if row else f"(table {t} missing)")

    print("\n== CATEGORIES ==")
    dump(con, """SELECT c.id, c.customLabel, c.enabled, c.position, COUNT(d.rowid) AS apps
                 FROM Category c LEFT JOIN DrawerItem d ON d.categoryId = c.id
                 GROUP BY c.id ORDER BY c.position""")

    print("\n== APPS (category | label | key to use in the plan | hidden | launch counts) ==")
    cols = table_cols(con, "DrawerItem")
    need = {"label", "packageName", "activityName", "categoryId", "hidden"}
    if need - set(cols):
        print("Missing columns:", need - set(cols), "- tell the assistant; the script needs adapting.")
    else:
        counters = [c for c in ("counterDrawerPanel", "counterSearchPanel") if c in cols]
        extra = ", ".join(counters) if counters else "0"
        for r in con.execute(f"""SELECT categoryId, label, packageName, activityName, hidden, {extra}
                                 FROM DrawerItem ORDER BY categoryId, label"""):
            key = f"{r[2]}/{r[3]}"
            print(f"{r[0]} | {r[1]} | {key} | hidden={r[4]} | {' / '.join(str(x) for x in r[5:])}")

    print("\n== HOME ITEMS ==")
    dump(con, "SELECT rowid AS rowid_, * FROM HomeItem ORDER BY configId, screen, cellY, cellX")
    print("\n== LAUNCHABLE ==")
    dump(con, "SELECT * FROM Launchable")
    print("\n== ACTION ==")
    dump(con, "SELECT * FROM Action")

    print("\n== LAYOUTS (configId: items, apps/folders, widgets, screens) ==")
    dump(con, """SELECT configId, COUNT(*) AS items, SUM(idLaunchable IS NOT NULL) AS launchables,
                 SUM(idWidget IS NOT NULL) AS widgets, COUNT(DISTINCT screen) AS screens
                 FROM HomeItem GROUP BY configId ORDER BY configId""")
    print("\n== FOLDERS ==")
    dump(con, """SELECT a.idLaunchable AS folder_id, a.label,
                 (SELECT COUNT(*) FROM Launchable k WHERE k.idParentFolderLaunchable = a.idLaunchable) AS apps,
                 (SELECT GROUP_CONCAT(h.configId) FROM HomeItem h WHERE h.idLaunchable = a.idLaunchable) AS layout
                 FROM Action a WHERE a.type = 9""")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
