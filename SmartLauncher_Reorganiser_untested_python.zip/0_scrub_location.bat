@echo off
rem Drag your .slbk backup onto this file. It makes a copy without your last known location.
if "%~1"=="" (
  echo Drag your .slbk backup onto this file.
  pause
  exit /b
)
set PY=python
where py >nul 2>&1 && set PY=py
%PY% "%~dp0slb_scrub.py" "%~1"
echo.
pause
