"""Smart Launcher backup reorganiser. Never changes your original backup.

Usage:  python slb_apply.py your_backup.slbk plan.json
Writes a new file next to the original: your_backup_v1.slbk (then _v2, ...).
"""
import copy
import struct
import json
import os
import sqlite3
import sys
import tempfile
import zipfile

DB = "databases/ginlemon.flower.db"
sys.stdout.reconfigure(encoding="utf-8")


def fail(msg):
    sys.exit(f"STOPPED: {msg}\nNothing was written.")


def load_plan(path):
    plan = json.load(open(path, encoding="utf-8"))
    cats = plan.get("categories") or fail("plan has no 'categories'")
    ids = [c.get("id") for c in cats]
    if len(set(ids)) != len(ids) or not all(ids):
        fail("category ids must be unique and non-empty")
    plan.setdefault("apps", {})
    plan.setdefault("hide", [])
    plan.setdefault("home_moves", [])
    plan.setdefault("folders", [])
    plan.setdefault("drawer_sort", None)
    ds = plan["drawer_sort"]
    if ds and ds.get("thumb") not in ("right", "left"):
        fail("drawer_sort needs \"thumb\": \"right\" or \"left\"")
    plan.setdefault("default_category", ids[-1])
    if plan["default_category"] not in ids:
        fail("default_category is not one of the categories")
    for k, v in plan["apps"].items():
        if v not in ids:
            fail(f"app {k} points to unknown category '{v}'")
    return plan

import re


def patch_headers(path):
    """Python rewrites zip flags/attributes; set them back to what Smart Launcher's own backups use
    (UTF-8 flag on, no data descriptor, external attributes 0)."""
    b = bytearray(open(path, "rb").read())
    eocd = b.rfind(b"PK\x05\x06")
    count, _, cd_off = struct.unpack_from("<HII", b, eocd + 10)
    pos = cd_off
    for _ in range(count):
        if b[pos:pos + 4] != b"PK\x01\x02":
            fail("unexpected zip layout while patching headers; delete the output file")
        flags = struct.unpack_from("<H", b, pos + 8)[0]
        struct.pack_into("<H", b, pos + 8, (flags & ~0x08) | 0x800)
        struct.pack_into("<I", b, pos + 38, 0)
        lho = struct.unpack_from("<I", b, pos + 42)[0]
        lflags = struct.unpack_from("<H", b, lho + 6)[0]
        struct.pack_into("<H", b, lho + 6, (lflags & ~0x08) | 0x800)
        nlen, xlen, clen = struct.unpack_from("<HHH", b, pos + 28)
        pos += 46 + nlen + xlen + clen
    open(path, "wb").write(b)


def drawer_columns(zin):
    """Columns of the app drawer (portrait), from the launcher profile in the settings; default 4."""
    for n in zin.namelist():
        if n.startswith("shared_prefs/") and n.endswith(".xml"):
            text = zin.read(n).decode("utf-8", "replace")
            for m in re.finditer(r'name="launcher_profile_#?\d+"[^>]*?(?:value="([^"]*)"|>([^<]*)<)', text):
                m2 = re.search(r"portraitColumns&quot;:(\d+)|portraitColumns\":(\d+)", m.group(1) or m.group(2) or "")
                if m2:
                    return int(m2.group(1) or m2.group(2))
    return 4


def read_pref(zin, name):
    for n in zin.namelist():
        if n.startswith("shared_prefs/") and n.endswith(".xml"):
            m = re.search(rf'name="{name}"[^>]*?value="([^"]*)"', zin.read(n).decode("utf-8", "replace"))
            if m:
                return m.group(1)
    return None


def set_drawer_prefs(data):
    """Switch the drawer to manual order. Only this one setting changes."""
    text = data.decode("utf-8")
    text, n = re.subn(r'(name="drawerOrder"[^>]*?value=")\d+(")', r"\g<1>3\g<2>", text)
    if not n:
        fail("could not find the drawer sort setting in this backup; remove 'drawer_sort' from the plan")
    return text.encode("utf-8")


def sort_drawer_by_usage(con, categories, thumb, cols, from_bottom):
    """Manual order, one rank per tab. Most used first.
    Stack from the bottom ON: position 0 is the bottom-right cell, rows go leftwards and then up
      (verified on a real phone). Right-handed: most used = position 0. Left-handed: mirror inside each row.
    Stack from the bottom OFF: assumed reading order (position 0 top-left, rows go rightwards and down),
      same idea from the top: left-handed: most used = position 0; right-handed: mirror inside each row."""
    mirror = (thumb == "left") if from_bottom else (thumb == "right")
    for cat in categories:
        rows = con.execute("""SELECT rowid, hidden, counterDrawerPanel + counterSearchPanel, label FROM DrawerItem
                              WHERE categoryId = ?""", (cat,)).fetchall()
        visible = sorted((r for r in rows if not r[1]), key=lambda r: (-r[2], r[3].lower()))
        hidden = sorted((r for r in rows if r[1]), key=lambda r: r[3].lower())
        v = len(visible)
        for rank, r in enumerate(visible):
            pos = rank
            if mirror:
                start = (rank // cols) * cols
                size = min(cols, v - start)
                pos = start + (size - 1 - (rank % cols))
            con.execute("UPDATE DrawerItem SET position=? WHERE rowid=?", (pos, r[0]))
        for i, r in enumerate(hidden):
            con.execute("UPDATE DrawerItem SET position=? WHERE rowid=?", (v + i, r[0]))


def component_of(intent):
    m = re.search(r"component=([^;]+)", intent or "")
    return m.group(1) if m else None


def make_folders(con, plan):
    """Create home screen folders in the Smart Launcher 6 (Room) format. Stops if the format differs."""
    if not plan["folders"]:
        return 0
    expect = {
        "Launchable": {"id", "iconGroupId", "idParentFolderLaunchable", "position"},
        "Action": {"idLaunchable", "actionId", "type", "intentUri", "userId", "label", "customLabel",
                   "deepShortcutId", "originalIcon", "color", "folderColor", "customIconProps"},
        "HomeItem": {"id", "idLaunchable", "idWidget", "screen", "configId", "cellX", "cellY", "spanX", "spanY", "zIndex"},
        "DrawerItem": {"label", "packageName", "activityName", "userId", "dominantColor"},
    }
    for t, cols in expect.items():
        have = set(cols_of(con, t))
        if (have != cols) if t != "DrawerItem" else not cols <= have:
            fail(f"folders: table {t} doesn't match the expected format, so this backup version isn't supported "
                 "for folders. Remove 'folders' from the plan.")

    folder_color = con.execute("SELECT color FROM Action WHERE type = 9 AND color IS NOT NULL LIMIT 1").fetchone()
    folder_color = folder_color[0] if folder_color else -16746288

    created = 0
    for fol in plan["folders"]:
        cfg = fol["configId"]
        cur = con.execute("INSERT INTO Launchable (iconGroupId, idParentFolderLaunchable, position) VALUES (NULL, NULL, -1)")
        newF = cur.lastrowid
        con.execute("INSERT INTO Action (idLaunchable, actionId, type, intentUri, userId, label, customLabel, deepShortcutId,"
                    " originalIcon, color, folderColor, customIconProps) VALUES (?,1,9,?,-1,?,0,NULL,0,?,NULL,NULL)",
                    (newF, f"#Intent;action=ginlemon.flower.openFolder;i.ginlemon.flower.folderId={newF};end",
                     fol["name"], folder_color))
        con.execute("INSERT INTO HomeItem (idLaunchable, idWidget, screen, configId, cellX, cellY, spanX, spanY, zIndex)"
                    " VALUES (?, NULL, ?, ?, ?, ?, 1, 1, 1)",
                    (newF, fol.get("screen", 0), cfg, float(fol["cellX"]), float(fol["cellY"])))

        for pos, key in enumerate(fol["apps"]):
            pkg = key.split("/")[0]
            # apps already on THIS layout (loose, or inside a folder of this layout)
            rows = con.execute("""SELECT a.idLaunchable, a.intentUri FROM Action a JOIN Launchable l ON l.id = a.idLaunchable
                WHERE a.type = 7 AND a.idLaunchable != ? AND (
                  EXISTS (SELECT 1 FROM HomeItem h WHERE h.idLaunchable = l.id AND h.configId = ?)
                  OR EXISTS (SELECT 1 FROM HomeItem h WHERE h.idLaunchable = l.idParentFolderLaunchable AND h.configId = ?))""",
                (newF, cfg, cfg)).fetchall()
            cands = [r[0] for r in rows
                     if component_of(r[1]) == key or ("/" not in key and (component_of(r[1]) or "").split("/")[0] == pkg)]
            if len(cands) > 1:
                fail(f"folders: '{key}' matches several apps on this layout; use package/activity")
            if cands:
                xl = cands[0]
                con.execute("UPDATE Launchable SET idParentFolderLaunchable=?, position=? WHERE id=?", (newF, pos, xl))
                con.execute("DELETE FROM HomeItem WHERE idLaunchable=? AND configId=?", (xl, cfg))
            else:
                di = con.execute("SELECT label, packageName, activityName, userId, dominantColor FROM DrawerItem "
                                 "WHERE packageName || '/' || activityName = ? OR packageName = ?", (key, key)).fetchall()
                if len(di) != 1:
                    fail(f"folders: app '{key}' not found uniquely in the app list")
                label, dpkg, dact, uid, color = di[0]
                xl = con.execute("INSERT INTO Launchable (iconGroupId, idParentFolderLaunchable, position) VALUES (NULL, ?, ?)",
                                 (newF, pos)).lastrowid
                con.execute("INSERT INTO Action (idLaunchable, actionId, type, intentUri, userId, label, customLabel,"
                            " deepShortcutId, originalIcon, color, folderColor, customIconProps)"
                            " VALUES (?,1,7,?,?,?,0,NULL,0,?,NULL,NULL)",
                            (xl, "#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;"
                                 f"launchFlags=0x10000000;component={dpkg}/{dact};end", uid or 0, label, color))
        created += 1

    bad = con.execute("SELECT COUNT(*) FROM Action WHERE idLaunchable NOT IN (SELECT id FROM Launchable)").fetchone()[0]
    bad += con.execute("SELECT COUNT(*) FROM Launchable WHERE idParentFolderLaunchable IS NOT NULL AND "
                       "idParentFolderLaunchable NOT IN (SELECT id FROM Launchable)").fetchone()[0]
    if bad:
        fail("folders: created broken rows; aborting")
    return created


def cols_of(con, table):
    return [r[1] for r in con.execute(f'PRAGMA table_info("{table}")')]


def hw_dupes(con):
    return con.execute("""SELECT COUNT(*) FROM (SELECT 1 FROM HomeItem WHERE idLaunchable IS NOT NULL
                          GROUP BY configId, screen, cellX, cellY HAVING COUNT(*) > 1)""").fetchone()[0]


def fk_count(con):
    return len(con.execute("PRAGMA foreign_key_check").fetchall())


def main(backup, plan_path):
    plan = load_plan(plan_path)
    zin = zipfile.ZipFile(backup)
    if DB not in zin.namelist():
        fail(f"{DB} not found in the backup")

    tmp = tempfile.mkdtemp()
    for n in zin.namelist():
        if n.startswith(DB):
            with open(os.path.join(tmp, os.path.basename(n)), "wb") as f:
                f.write(zin.read(n))
    dbfile = os.path.join(tmp, os.path.basename(DB))
    con = sqlite3.connect(dbfile)

    for t, need in {"Category": {"id", "customLabel", "enabled", "position"},
                    "DrawerItem": {"packageName", "activityName", "categoryId", "hidden"},
                    "HomeItem": {"configId", "screen", "cellX", "cellY"}}.items():
        missing = need - set(cols_of(con, t))
        if missing:
            fail(f"table {t} is missing columns {sorted(missing)}; this backup version needs a different script")

    fk_before, dup_before = fk_count(con), hw_dupes(con)

    # drawer sort mode: 3 = manual ("by user"), where each app's position matters; other modes ignore it
    manual = False
    for n in zin.namelist():
        if n.startswith("shared_prefs/") and n.endswith(".xml"):
            m = re.search(r'name="drawerOrder"[^>]*?value="(\d+)"', zin.read(n).decode("utf-8", "replace"))
            manual = bool(m and m.group(1) == "3")

    # --- categories ---
    ccols = cols_of(con, "Category")
    template = con.execute("SELECT * FROM Category LIMIT 1").fetchone()
    existing = {r[0] for r in con.execute("SELECT id FROM Category")}
    for pos, c in enumerate(plan["categories"]):
        if c["id"] in existing:
            con.execute("UPDATE Category SET customLabel=?, position=?, enabled=1 WHERE id=?",
                        (c.get("label"), pos, c["id"]))
        else:
            if template is None:
                fail("the backup has no Category rows to copy a template from")
            row = dict(zip(ccols, template))
            row.update(id=c["id"], customLabel=c.get("label"), position=pos, enabled=1)
            con.execute(f"INSERT INTO Category ({','.join(ccols)}) VALUES ({','.join('?' * len(ccols))})",
                        [row[k] for k in ccols])

    # --- apps ---
    hide = set(plan["hide"])
    moved = hidden = 0
    order = []  # (rowid, old category, new category, old position)
    for rowid, pkg, act, oldcat, oldpos in con.execute(
            "SELECT rowid, packageName, activityName, categoryId, position FROM DrawerItem").fetchall():
        key = f"{pkg}/{act}"
        target = plan["apps"].get(key) or plan["apps"].get(pkg) or plan["default_category"]
        con.execute("UPDATE DrawerItem SET categoryId=? WHERE rowid=?", (target, rowid))
        order.append((rowid, oldcat, target, oldpos))
        moved += 1
        if key in hide or pkg in hide:
            con.execute("UPDATE DrawerItem SET hidden=1 WHERE rowid=?", (rowid,))
            hidden += 1

    if manual:
        # manual order keeps one rank per tab (0, 1, 2...): keep the apps already in a tab in their order,
        # and put apps moved in at the end, in their old relative order
        for cat in {o[2] for o in order}:
            stay = sorted((o for o in order if o[2] == cat and o[1] == cat), key=lambda o: o[3])
            come = sorted((o for o in order if o[2] == cat and o[1] != cat), key=lambda o: o[3])
            for rank, o in enumerate(stay + come):
                con.execute("UPDATE DrawerItem SET position=? WHERE rowid=?", (rank, o[0]))

    if plan["drawer_sort"]:
        # a missing setting is treated as off (the app's default is not confirmed)
        from_bottom = read_pref(zin, "stackFromBottom") == "true"
        sort_drawer_by_usage(con, [c["id"] for c in plan["categories"]], plan["drawer_sort"]["thumb"],
                             drawer_columns(zin), from_bottom)

    keep = [c["id"] for c in plan["categories"]]
    con.execute(f"DELETE FROM Category WHERE id NOT IN ({','.join('?' * len(keep))})", keep)

    # --- home screen moves (by rowid_ from the inspect output) ---
    for m in plan["home_moves"]:
        con.execute("UPDATE HomeItem SET cellX=?, cellY=? WHERE rowid=?", (m["cellX"], m["cellY"], m["rowid"]))
    folders_made = make_folders(con, plan)
    con.commit()

    # --- validate ---
    problems = []
    if con.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
        problems.append("integrity_check failed")
    if fk_count(con) > fk_before:
        problems.append("new foreign key violations")
    if hw_dupes(con) > dup_before:
        problems.append("new overlapping home items")
    if con.execute("SELECT COUNT(*) FROM DrawerItem WHERE categoryId NOT IN (SELECT id FROM Category)").fetchone()[0]:
        problems.append("apps point to a missing category")
    if con.execute("SELECT COUNT(*) FROM Category").fetchone()[0] != len(keep):
        problems.append("category count differs from the plan")
    report = con.execute("""SELECT c.position, c.id, c.customLabel,
                            SUM(CASE WHEN d.hidden=0 THEN 1 ELSE 0 END), COUNT(d.rowid)
                            FROM Category c LEFT JOIN DrawerItem d ON d.categoryId=c.id
                            GROUP BY c.id ORDER BY c.position""").fetchall()
    for _, cid, _, visible, _ in report:
        if not visible:
            problems.append(f"category '{cid}' has no visible apps (empty tab)")
    if problems:
        fail("; ".join(problems))
    con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    con.close()

    # --- repack, same order, same headers ---
    stem, _ = os.path.splitext(backup)
    n = 1
    while os.path.exists(f"{stem}_v{n}.slbk"):
        n += 1
    out_path = f"{stem}_v{n}.slbk"
    dropped = []
    prefs_edited = None
    with zipfile.ZipFile(out_path, "w") as zout:
        for info in zin.infolist():
            if info.filename.startswith(DB):
                f = os.path.join(tmp, os.path.basename(info.filename))
                if not os.path.exists(f):
                    dropped.append(info.filename)
                    continue
                data = open(f, "rb").read()
            else:
                data = zin.read(info)
                if plan["drawer_sort"] and info.filename.startswith("shared_prefs/") and info.filename.endswith(".xml") \
                        and b'name="drawerOrder"' in data:
                    data = set_drawer_prefs(data)
                    prefs_edited = info.filename
            zout.writestr(copy.copy(info), data, compress_type=info.compress_type)

    patch_headers(out_path)

    # --- verify the output ---
    zchk = zipfile.ZipFile(out_path)
    if zchk.testzip():
        fail("output zip failed its own check; delete " + out_path)
    changed = []
    for info in zin.infolist():
        if info.filename in dropped:
            continue
        new = zchk.getinfo(info.filename)
        if (new.create_system, new.external_attr, new.compress_type, new.flag_bits & 0x800) != \
           (info.create_system, info.external_attr, info.compress_type, info.flag_bits & 0x800):
            problems.append(f"header differs: {info.filename}")
        if zchk.read(info.filename) != zin.read(info) and not info.filename.startswith(DB):
            if info.filename == prefs_edited:
                def vals(b):
                    return dict(re.findall(r'name="([^"]+)"[^>]*?value="([^"]*)"', b.decode("utf-8")))
                a, b = vals(zin.read(info)), vals(zchk.read(info.filename))
                diff = {k for k in set(a) | set(b) if a.get(k) != b.get(k)}
                if not diff <= {"drawerOrder"}:
                    problems.append(f"settings differ beyond the drawer sort: {sorted(diff)}")
            else:
                problems.append(f"content differs: {info.filename}")
        if info.filename.startswith(DB):
            changed.append(info.filename)
    if problems:
        fail("; ".join(problems) + f"; delete {out_path}")

    print(f"OK. Wrote {out_path}")
    print(f"Apps assigned: {moved}, hidden: {hidden}, home items moved: {len(plan['home_moves'])}, folders created: {folders_made}")
    print("Only changed entry:", ", ".join(changed) + (f" and the drawer sort settings in {prefs_edited}" if prefs_edited else ""))
    if plan["drawer_sort"]:
        print(f"Drawer: manual order, apps ordered by use for {plan['drawer_sort']['thumb']}-handed, "
              f"{'from the bottom up (stack from bottom is on)' if from_bottom else 'from the top down (stack from bottom is off)'}.")
    if dropped:
        print("Left out (merged into the database on save):", ", ".join(dropped))
    if manual:
        print("Drawer order is manual: positions were renumbered per tab; apps moved into a tab sit at its end.")
    print("\nTabs (position | id | label | visible apps | total):")
    for pos, cid, label, visible, total in report:
        print(f"  {pos} | {cid} | {label} | {visible} | {total}")
    print("\nOriginal backup untouched. Restore the new file via Smart Launcher's backup/restore option.")
    print("The lock-screen wallpaper may reset; set it again if so.")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
