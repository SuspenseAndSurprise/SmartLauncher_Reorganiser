"""Removes your last known location from a Smart Launcher backup, before you upload it anywhere.
Writes a new file next to the original: your_backup_nolocation.slbk. The original is never changed.
Everything else in the backup stays exactly the same.

Usage:  python slb_scrub.py your_backup.slbk
"""
import copy
import os
import re
import sys
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from slb_apply import patch_headers  # noqa: E402  (restores the zip header values Python overwrites)

sys.stdout.reconfigure(encoding="utf-8")
PAT = re.compile(r'[ \t]*<string name="last_position">[^<]*</string>[ \t]*\r?\n?')


def main(path):
    zin = zipfile.ZipFile(path)
    out_path = os.path.splitext(path)[0] + "_nolocation.slbk"
    if os.path.exists(out_path):
        sys.exit(f"{out_path} already exists; move it away first.")
    removed = 0
    with zipfile.ZipFile(out_path, "w") as zout:
        for info in zin.infolist():
            data = zin.read(info)
            if info.filename.startswith("shared_prefs/") and info.filename.endswith(".xml"):
                text = data.decode("utf-8")
                text, n = PAT.subn("", text)
                removed += n
                data = text.encode("utf-8")
            zout.writestr(copy.copy(info), data, compress_type=info.compress_type)
    patch_headers(out_path)
    chk = zipfile.ZipFile(out_path)
    if chk.testzip():
        os.remove(out_path)
        sys.exit("Output failed its own check; nothing written.")
    print(f"Wrote {out_path}")
    print("Location entry removed." if removed else "No location entry found; the file is an unchanged copy.")
    print("Only the settings file can differ from your original. The wallpaper and the home screen screenshot are still inside.")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
