SMART LAUNCHER REORGANISER
==========================
Tidies your Smart Launcher 6 app drawer (tabs, app sorting, hidden apps) and
optionally moves home screen items, from a backup file (.slbk).
Your original backup is never changed. You get a new file to restore.

Before you start: make a backup in Smart Launcher's settings (backup option)
and copy the .slbk file to your computer. Keep that original as a fallback.

Free or Pro: Smart Launcher's docs list editable categories (custom tabs) as a
Pro feature. Everything here was tested on Pro: restoring a backup with new,
renamed and reordered tabs (with icons), moved apps, a new home screen folder
and moved home icons all worked. What the free version does with a backup that
has custom tabs is unknown: it may show them, ignore them or reset them. If
you're on free, check the first result on your phone before going further.

Which AI (Way A): it must accept the .slbk upload (it's a zip; if the upload is
refused, rename it to .zip), extract it, run Python and hand back a new file.
Not every chatbot can. Claude and Grok worked in testing. ChatGPT, Copilot and
others may work, depending on their current limits (not tested; Copilot refused
the zip for me and Lumo can't upload it). Gemini's app takes zip files but
Google says only up to 10 files per archive, and a backup usually has more, so
use Way B with those. Way B works with any chat model.

Privacy: the backup holds your app list, layout, launch counts, cached news
articles, your wallpaper, a screenshot of your home screen and the launcher's
settings. The settings include your phone model and a last known location
(coordinates), probably for the weather; that's my guess, not confirmed. In the
backup I checked there were no email addresses, phone numbers, passwords or
contact names.
- Way A uploads the whole backup to the AI. To remove the location first, drag
  the backup onto 0_scrub_location.bat (or: python slb_scrub.py backup.slbk).
  It makes backup_nolocation.slbk and changes nothing else. Restoring such a
  file was tested and works, but the launcher writes the location again by
  itself, so repeat it for each new backup. The wallpaper and screenshot stay
  inside, so check those yourself.
- Way B only pastes the inspect report (app list, layout, launch counts), not
  the location, wallpaper or screenshot. Use a local model if you'd rather not
  send even that anywhere.
Don't post the backup publicly.

WAY A: AI ASSISTANT WITH FILE ACCESS (easiest)
----------------------------------------------
Use an assistant that can open files and run Python (a cloud AI with code
execution, or a local model inside an agent tool).
1. Give it SmartLauncher_Reorganiser_agent.md as the instructions.
2. Attach your .slbk backup.
3. Answer its questions. It builds the new backup itself and checks it.
No Python setup on your side.


WAY B: ANY CHAT MODEL, YOU RUN THE SCRIPTS
------------------------------------------
Works with any chat model, including local ones without tools.
Needs Python 3.8+ on your computer. Nothing to install: it only uses
Python's standard library.

1. Start a chat and paste the contents of PROMPT_for_chat.md.
2. Run the inspector on your backup:
     Windows:  drag the .slbk onto 1_inspect.bat
               (creates inspect_output.txt)
     Other:    python slb_inspect.py backup.slbk > inspect_output.txt
3. Paste inspect_output.txt into the chat and answer the questions.
4. At the end the model gives you a plan as JSON. Save it as plan.json
   in this folder (see plan_example.json for the shape).
5. Build the new backup:
     Windows:  drag the ORIGINAL .slbk onto 2_apply.bat
     Other:    python slb_apply.py backup.slbk plan.json
   This writes backup_v1.slbk next to the original and prints a report.
   If it prints STOPPED, nothing was written: paste the message into the chat.
6. Restore backup_v1.slbk in Smart Launcher's backup/restore option.
   The lock-screen wallpaper may reset; set it again if so.

What the scripts do and don't do
- They change the drawer: tabs, tab names and order, which tab each app is in,
  hidden apps, and optionally the order of apps inside tabs. They can also move home screen items to new grid cells and
  create home screen folders (see below).
- They don't touch widgets, custom icons or any other file in the backup. The
  dock is left alone unless you accept the suggested new order (apps
  already in it are reordered, never added or removed). Everything else is copied unchanged and checked after writing.
- Drawer order, only if you pick "By user" (a custom order for your thumb)
  instead of "By used" (Smart Launcher keeps sorting by use): the script
  switches the drawer sort from By used to By user, once, and ranks each tab's
  apps by use, most used nearest your thumb. It no longer updates by itself;
  switch back in Smart Launcher's settings if you want By used again. It reads Smart Launcher's "stack apps
  from the bottom" setting from the backup: ON = it orders from the bottom up
  (most used bottom-right for right-handed, bottom-left for left-handed), OFF =
  from the top down (top-left for left-handed, top-right for right-handed).
  Checked on a real phone: left and right handed, with the setting on and off.
  Without this step the order isn't touched: with manual order it keeps the
  order inside each tab and puts moved apps at the end; with most used it
  leaves positions alone.
- No dock? The scripts won't create one. Turn it on in Smart Launcher and make
  a new backup if you want one.
- Checks before writing: database integrity, no apps in missing tabs, no empty
  tabs, no new overlapping home items.
- Python's name is "python" or "py" on Windows, "python3" on Linux/macOS.

Tested: a real backup with 396 apps (6 tabs became 8), 14 loose home apps,
3 folders and a dock of 8 apps, restored on Smart Launcher 6 Pro (data
version 64). Other versions may differ.

Home screen folders (Way B)
The script builds folders in the format it saw in a real backup (Smart Launcher
6, backup data version 64). If your backup looks different it stops and writes
nothing; then leave folders out of the plan. Check the result on your phone and
keep your original.

Files
- PROMPT_for_chat.md   instructions for Way B chats
- slb_inspect.py       read-only report of your backup
- slb_apply.py         applies plan.json, validates, writes the new backup
- slb_scrub.py         removes the last known location from a backup copy
- 0_scrub_location.bat / 1_inspect.bat / 2_apply.bat   optional Windows helpers
- plan_example.json    example plan
- SmartLauncher_Reorganiser_agent.md (separate file) for Way A
