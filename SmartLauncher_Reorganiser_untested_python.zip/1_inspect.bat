@echo off
rem Drag your .slbk backup onto this file.
if "%~1"=="" (
  echo Drag your .slbk backup onto this file.
  pause
  exit /b
)
set PY=python
where py >nul 2>&1 && set PY=py
%PY% "%~dp0slb_inspect.py" "%~1" > "%~dp0inspect_output.txt"
echo.
echo Done. Open inspect_output.txt and paste its contents into the chat.
pause
